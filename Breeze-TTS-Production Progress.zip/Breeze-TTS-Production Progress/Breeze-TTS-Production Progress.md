# Breeze-TTS-Production Progress

**Date**：2026/5/8

---

# Reference Audio Sources

The number of speakers must be balanced.

- **Too few speakers:** the data distribution is not diverse enough.
- **Too many speakers:** each speaker only has a few seconds of audio, which makes it hard for the model to learn a good speaker embedding.

To manage all speakers, we maintain a `speaker_table` with the following fields:

| **Field Name** | **Example** |
| --- | --- |
| row_id | 1 |
| sperker_id | 00335f44eef95697c18b8674efb2e701745e95221777216ecb5996673ac4e10c875b6e078dbaf462dd9104cbc3b57dca66ce8a65282ebdfcf47403a2075e0ea2 |
| wavFile | common_voice_zh-TW_31049337 |
| transcript | 這時期應該是個人套餐 |
| wav_length | 2.1 sec |
| source | CommonVoice25 |
| total_sentences | 0 |
| total_audio_seconds | 0 |
| created_date | 2026-04-16 |
| gender | male_masculine |
| age | thirties |
| speech_rate | TBD |

The current audio sources are listed below.

| **Source** | **# Speakers** | **Filtering Conditions** |
| --- | --- | --- |
| MediaTek-Research/formosaspeech | 417 | postprocess = “無混雜訊”
duration_sec < 20
text not empty
audio-text pairs are consistent |
| Common Voice Scripted Speech 25.0 - Chinese (Taiwan)
 | 2241 | TBD |

# Reference Text Sources

Control the number of unique sentences to ensure balanced coverage of Chinese characters and Bopomofo as much as possible.

Sentence duration should also follow a reasonable distribution between 1–20 seconds.

To manage all sentences, we maintain a `sentence_table` with the following fields:

| **Field Name** | **Example** |
| --- | --- |
| row_id | 28687 |
| sentence_id | 0dc7b2e1174642385c81554762f586df4c8b34e538feb31bdcdf57659a6c6c4b |
| sentence | 有某種程度是對的 |
| source_type | YouTube Subtitles |
| source_name | boyin_EP201 |
| sentence_length | 8 |
| used_count | 0 |
| created_date | 2026-04-16 |

The current audio sources are listed below. There are a total of 409,949 unique sentences.

| **Type** | **Source** | **# Sentences** | **Ratio** |
| --- | --- | --- | --- |
| YouTube Subtitles | 只能喝酒的圖書館 | 72,000 | 17.56% |
| YouTube Subtitles | 志祺七七 | 72,000 | 17.56% |
| YouTube Subtitles | 博音 | 61,905 | 15.10% |
| YouTube Subtitles | Sherry's Notes 雪力的心理學筆記 | 58,051 | 14.16% |
| YouTube Subtitles | 范琪斐的美國時間 | 51,368 | 12.53% |
| YouTube Subtitles | 唐綺陽官方專屬頻道 | 45,514 | 11.10% |
| Dataset | CommonVoice25 | 20,527 | 5.01% |
| YouTube Subtitles | Cofit x 宋晏仁醫師 - 初日醫學 | 16,245 | 3.96% |
| YouTube Subtitles | High A Day | 11,093 | 2.71% |
| Dataset | MediaTek-Research/formosaspeech | 1,246 | 0.30% |

The distribution of sentence lengths is shown in the figure below.

![image.png](Breeze-TTS-Production%20Progress/image.png)

# Audio Sources & Text Sources Pairing

Each speaker samples 3,500 sentences from the `sentence_table`, resulting in an expected contribution of approximately 3.8 hours of speech per speaker. The sampling process follows a predefined sentence-length distribution, where different numbers of sentences are drawn from each length bucket to balance short and long utterances.

The detailed sampling rules are shown in the table below.

| **Sentence Length**  | **Ratio (%)** | **# Sentences** | **# Sentences per Speaker** |  **Allocation Ratio(%)** | **#Repeats per Sentence** | **Expected Size** |
| --- | --- | --- | --- | --- | --- | --- |
| 1–4 | 4.59 | 18,805 | 175 | **5.00%** | 24.74 | 465,150 |
| 5–8 | 35.83 | 146,882 | 1,200 | **34.29%** | 21.72 | 3,189,600 |
| 9–14 | 42.98 | 176,209 | 1,375 | **39.29%** | 20.74 | 3,654,750 |
| 15–20 | 15.57 | 63,818 | 700 | **20.00%** | 29.15 | 1,860,600 |
| 21–30 | 0.86 | 3,519 | 40 | **1.14%** | 30.21 | 106,320 |
| 31–45 | 0.09 | 363 | 4 | **0.11%** | 29.29 | 10,632 |
| 46–60 | 0.03 | 104 | 2 | **0.06%** | 51.12 | 5,316 |
| 61–80 | 0.03 | 114 | 2 | **0.06%** | 46.63 | 5,316 |
| 80+ | 0.03 | 135 | 2 | **0.06%** | 39.38 | 5,316 |
| Total | 100 | 409,949 | 3,500 | **100.00%** |  | 9,303,000 |

To manage all pairing data , we maintain a `pairing_table` with the following fields:

| **Field Name** | **Example** |
| --- | --- |
| speaker_prompt_audio_filename | common_voice_zh-TW_21270221 |
| speaker_id | 816aa1e278293a2b39d799a4046b832b64c6c8bf92786ac149cde1ff8df3668521f047ea3678cf5c2f1e72ee434133500301f78f9d5cc94dd7a33f819ef106c8 |
| speaker_prompt_text_transcription | 想把所有能收到的發票都存入載具內 |
| content_to_synthesize | 受到影響的人 |
| sentence_id | 83c0b39bc3d24640e567882b841f4298335fb0da4aa6cb89de8f33762c98223a |
| output_audio_filename | SD0003938210 |

# Training Data Filtering

## **ASR**

This code uses the [faster-whisper](https://github.com/SYSTRAN/faster-whisper?utm_source=chatgpt.com) model to perform speech-to-text transcription on `.wav` audio files. The example output includes the detected language, language confidence probability, audio duration, and transcribed text.

We retain samples with a Character Error Rate (CER) below 5%. In experiments conducted on 114,820 `.wav` files, the retention rate was approximately 82.82%.

## **Speaker Embedding Similarity**

Using [3D-Speaker](https://github.com/modelscope/3D-Speaker), we compute the embedding similarity between the reference speaker audio and the generated audio, with scores ranging from 0 to 1. We then apply an appropriate threshold to retain samples with higher speaker similarity.